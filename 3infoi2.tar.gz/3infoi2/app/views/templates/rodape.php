
<html>
<body>
<footer>Endereço</footer>
<footer>Telefone</footer>
</body>
</html>