
<h2>Inclusão de Categoria</h2>


<form method="post" action = "categorias.php?acao=">
    <label for="nome">Nome</label>
    <input type="text" name="nome">

    <label for="descricao">Descrição</label>

    <textarea name="descricao" id="descricao" cols="30" rows="10">

    </textarea>
    <br>
    <input type="submit" name="gravar" value="Gravar">

    <form>
